#!/bin/bash
#This script was written by Hashem Ouaida Feb 2022
#This is a simple script that displays the some text and exists the program with a code 0, which is handy for other purposes.
echo "Hi there!"

echo "It's good to see you $1"

exit 0

